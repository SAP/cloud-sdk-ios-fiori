import SwiftUI

// Namespace for Fiori-related style types
public enum Fiori {}
