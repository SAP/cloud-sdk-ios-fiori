import SwiftUI

public enum WelcomeState: Int, CaseIterable {
    case noConfigOption, useDiscoveryService, useBarcodeScanner, useBoth, configured
    
//    @ViewBuilder
//    var button: some View {
        
//        switch self {
//        case .noConfigOption:
//            Button(action: onStart) {
//                Text("Start")
//            }
//        case .useDiscoveryService:
//            Button(action: onStart) {
//                Text("Start")
//            }
//        case .useBarcodeScanner:
//            Button(action: onScan) {
//                Text("Scan")
//            }
//        case .useBoth:
//            Button(action: onStart) {
//                Text("Start")
//            }
//        case .configured:
//            Button(action: onStart) {
//                Text("Start")
//            }
//        }
//
        
//    }
}
