import SwiftUI

/// :nodoc:
public enum OnboardingState {
    case isConfigured
    case notConfiguredWithNoConfigOptions
    case notConfiguredAndWillConfigureWithDiscoveryServiceAndBarcodeScanner
    case notConfiguredAndWillConfigureWithDiscoveryService
    case notConfiguredAndWillConfigureWithBarcodeScanner
}
