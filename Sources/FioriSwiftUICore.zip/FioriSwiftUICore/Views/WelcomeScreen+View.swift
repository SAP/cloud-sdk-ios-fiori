// Generated using Sourcery 1.1.1 — https://github.com/krzysztofzablocki/Sourcery
// DO NOT EDIT
//TODO: Copy commented code to new file: `FioriSwiftUICore/Views/WelcomeScreen+View.swift`
//TODO: Implement default Fiori style definitions as `ViewModifier`
//TODO: Implement WelcomeScreen `View` body

/// - Important: to make `@Environment` properties (e.g. `horizontalSizeClass`), internally accessible
/// to extensions, add as sourcery annotation in `FioriSwiftUICore/Models/ModelDefinitions.swift`
/// to declare a wrapped property
/// e.g.:  `// sourcery: add_env_props = ["horizontalSizeClass"]`


import SwiftUI

// FIXME: - Implement Fiori style definitions

extension Fiori {
    enum WelcomeScreen {
        struct Title: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .font(.system(size: 28, weight: .thin, design: .default))
                    .foregroundColor(.preferredColor(.primary1))
                    .multilineTextAlignment(.center)
            }
        }
        
        struct DescriptionText: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .font(.system(size: 17))
                    .foregroundColor(.preferredColor(.primary1))
                    .multilineTextAlignment(.center)
            }
        }
        
        struct WelcomeButton: ViewModifier {
            @State var configType: OnboardingState = OnboardingState.isConfigured
            @State private var goToActivationScreen = false
            func body(content: Content) -> some View {
                Button(action: onStart) {
                    content
                        .frame(width: 169.0, height: 20.0)
                }
                .buttonStyle(FioriButtonStyle())
                .sheet(isPresented: $goToActivationScreen, content: {
                        ActivstionView()
                    })
            }
            func onStart() {
                print("check state on start clicked")
                switch configType {
                case OnboardingState.notConfiguredAndWillConfigureWithDiscoveryServiceAndBarcodeScanner:
                    goToActivationScreen = true
                case OnboardingState.notConfiguredAndWillConfigureWithDiscoveryService:
                    break
                case OnboardingState.notConfiguredAndWillConfigureWithBarcodeScanner:
                    break
                case OnboardingState.notConfiguredWithNoConfigOptions:
                    break
                case OnboardingState.isConfigured:
                    break
               
                }
            }
        }
        
        struct Subtitle: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .font(.system(size: 15))
                    .foregroundColor(.preferredColor(.primary1))
            }
        }
        
        struct Footnote: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .font(.system(size: 15))
                    .foregroundColor(.preferredColor(.primary1))
            }
        }
        
        struct ActionTitle: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .font(.system(size: 15))
                    .foregroundColor(.preferredColor(.tintColorDark))
                
            }
        }
        
        struct Icon: ViewModifier {
            func body(content: Content) -> some View {
                content
                    .scaleEffect(0.8, anchor: .center)
                    .frame(width: 20, height: 20, alignment: .center)
            }
        }
        
        // TODO: - substitute type-specific ViewModifier for EmptyModifier
        /*
         // replace `typealias Subtitle = EmptyModifier` with:
         
         struct Subtitle: ViewModifier {
         func body(content: Content) -> some View {
         content
         .font(.body)
         .foregroundColor(.preferredColor(.primary3))
         }
         }
         */
        static let title = Title()
        static let descriptionText = DescriptionText()
        static var welcomeButton = WelcomeButton(configType:        OnboardingState.notConfiguredAndWillConfigureWithDiscoveryServiceAndBarcodeScanner)
//        static let primaryButton = PrimaryButton()
        static let subtitle = Subtitle()
        static let footnote = Footnote()
        static let actionTitle = ActionTitle()
        static let icon = Icon()
        
    }
}

// FIXME: - Implement WelcomeScreen View body

extension WelcomeScreen: View {
    
    public var body: some View {
        if horizontalSizeClass == .some(.compact) {
            VStack {
                title
                    .padding(.top, 80)
                    .padding(.bottom, 40)
                descriptionText
                    .padding(.bottom, 80)
                welcomeButton
                    .padding(.bottom, 20)
                
                subtitle
                footnote
                    .padding(.top, 8)
                actionTitle
                
                Spacer()
                icon
                    .padding(.bottom, 32)
            }
            .padding(.leading, 32)
            .padding(.trailing, 32)
        } else {
            VStack {
                title
                    .padding(.top, 80)
                    .padding(.bottom, 40)
                descriptionText
                    .padding(.bottom, 80)
                welcomeButton
                    .padding(.bottom, 20)
                    .buttonStyle(FioriButtonStyle())
                
                subtitle
                footnote
                    .padding(.top, 8)
                actionTitle
                
                Spacer()
                icon
                    .padding(.bottom, 32)
            }
        }
    }
}

//struct ButtonModifier: ViewModifier {
//    @State var configState: OnboardingState = OnboardingState.isConfigured
//    @State private var goToActivationScreen = false
//    
////    var descText: String = ""
////    var buttonText = ""
//    
////    switch configState {
////        case .isConfigured:
////            descText = "Stay on top of your daily tasks management and easily collaborate on projects."
////            buttonText = "Start"
////
////        case.notConfiguredAndWillConfigureWithDiscoveryServiceAndBarcodeScanner:
////            descText = "Stay on top of your daily tasks management and easily collaborate on projects."
////            buttonText = "Start"
////
////        case .notConfiguredAndWillConfigureWithDiscoveryService:
////            descText = "Please enter your email address to start the activation process."
////            buttonText = "Start"
////
////        case .notConfiguredAndWillConfigureWithBarcodeScanner:
////            descText = "Please scan the secure QR code to start the activation process."
////            buttonText = "Scan"
////
////        default:
////            descText = "Please follow the instructions you received in the welcome email to start the activation process."
////            buttonText = "Start"
////    }
//    
//    func body(content: Content) -> some View {
//        return content
//            .onTapGesture{
//                    print("check state")
//                    if configState == OnboardingState.notConfiguredAndWillConfigureWithDiscoveryServiceAndBarcodeScanner {
//                        goToActivationScreen = true
//                    }
//                }
//            .sheet(isPresented: $goToActivationScreen, content: {
//                    ActivstionView()
//                })
//    }
//
//}

struct ActivstionView: View {
    public var body: some View {
        Text("ActivationView")
    }
}

struct WelcomeScreen_preview: PreviewProvider {
    static var previews: some View {
        WelcomeScreen(title: "SAP Project Companion for Managers", descriptionText: "Please follow the instructions you received in the welcome email to start the activation process.", welcomeButton: "Start", subtitle: "abc@def.com", footnote: "Want to explore?", actionTitle: "Try Demo", icon: Image("SAPLogo"))
    }
}
