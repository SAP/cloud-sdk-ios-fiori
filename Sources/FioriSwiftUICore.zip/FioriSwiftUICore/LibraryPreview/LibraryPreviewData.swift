import Foundation

public enum LibraryPreviewData {}
