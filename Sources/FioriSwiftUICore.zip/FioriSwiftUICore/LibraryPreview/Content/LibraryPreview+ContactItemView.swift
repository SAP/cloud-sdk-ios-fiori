import Foundation
import SwiftUI

// #if swift(>=5.3)
//    @available(iOS 14.0, *)
//    struct ContactItemLibraryContent: LibraryContentProvider {
//        @LibraryContentBuilder
//        var views: [LibraryItem] {
//            LibraryItem(ContactItem(model: LibraryPreviewData.Person.laurelosborn),
//                        category: .control)
////        LibraryItem(ContactItem(model: LibraryPreviewData.Person.laurelosborn, actionItems: LibraryPreviewData.Person.laurelosborn.actionItems), title: "ContactItem w/ActionItems", category: .control)
//        }
//
//        @LibraryContentBuilder
//        func modifiers(base: TextStyle) -> [LibraryItem] {
//            LibraryItem(
//                base.bold(),
//                title: "Bold"
//            )
//        }
//    }
// #endif
